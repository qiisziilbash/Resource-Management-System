package main;

import gui.StartMenu;

public class GUIStart {
    public static void main(String[] args)
    {
        new StartMenu().main();
    }
}
