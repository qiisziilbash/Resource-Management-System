package gui.controllers;

/**
 * Created by qizilbash on 7/2/2016.
 */
public enum Direction {
    TOP, DOWN, LEFT, RIGHT
}
