package businesslogic.distribution.requirement;

/**
 * Created by Esi on 6/26/2016.
 */
public enum RequirementPriorityEnum {
    ORDINARY,
    ESSENTIAL;
}
