package businesslogic.distribution.resource;

/**
 * Created by Esi on 6/26/2016.
 */
public enum ResourceStateEnum {
    UNALLOCATED,
    ALLOCATED;

}
