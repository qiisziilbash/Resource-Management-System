/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: 
 * License Type: Evaluation
 */
package businesslogic.distribution.resource;

public class FinancialResource extends businesslogic.distribution.resource.Resource {
	public FinancialResource() {
	}
	
	private int financialValue;
	
	public void setFinancialValue(int value) {
		this.financialValue = value;
	}
	
	public int getFinancialValue() {
		return financialValue;
	}
	
	public FinancialResource(int financialValue) {
		//TODO: Implement Method
		throw new UnsupportedOperationException();
	}
	
	public String toString() {
		return super.toString();
	}
	
}
