package businesslogic.distribution.resource;

/**
 * Created by Esi on 6/23/2016.
 */
public class ModuleState {
}
