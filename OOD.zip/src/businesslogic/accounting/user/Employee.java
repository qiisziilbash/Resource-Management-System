/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: 
 * License Type: Evaluation
 */
package businesslogic.accounting.user;

public class Employee extends businesslogic.accounting.user.User {
	public Employee() {
		super();
	}
	
	public Employee(String username, String password, String email, businesslogic.accounting.job.Job[] jobs) {
		//TODO: Implement Method
	}
	
	public String toString() {
		return super.toString();
	}
	
}
