package businesslogic;

import businesslogic.support.SystemConfiguration;

/**
 * Created by Esi on 6/22/2016.
 */
public class ClientAdminLogicFacade implements AdminLogicInterface{
    @Override
    public void configureSystem(SystemConfiguration configureSystem) {

    }
}
