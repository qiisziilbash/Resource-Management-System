package businesslogic.utility;

/**
 * Created by Esi on 6/23/2016.
 */
public class Tree<T> {
}
